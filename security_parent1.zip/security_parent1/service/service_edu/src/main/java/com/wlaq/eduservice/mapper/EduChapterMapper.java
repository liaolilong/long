package com.wlaq.eduservice.mapper;

import com.wlaq.eduservice.entity.EduChapter;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 课程 Mapper 接口
 * </p>
 *
 * @author testjava
 * @since 2020-02-24
 */
public interface EduChapterMapper extends BaseMapper<EduChapter> {

}
